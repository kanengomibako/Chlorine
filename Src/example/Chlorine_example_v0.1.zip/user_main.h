#ifndef USER_MAIN_H
#define USER_MAIN_H

#ifdef __cplusplus
extern "C" {
#endif

void mainInit();

void mainLoop();

void fxChange();

#ifdef __cplusplus
}
#endif

#endif // USER_MAIN_H
